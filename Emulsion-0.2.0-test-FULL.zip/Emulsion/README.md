# Emulsion — Android grain editor + research bench (0.2.0-test)

Offline Android editor prototype plus the complete research material carried forward from Research Bench 0.9.

## Android test app
- Import an existing image through Android Photo Picker.
- Preview render capped at 1400 px on the long edge; export renders at source dimensions.
- Controls: grain amount, estimated particle diameter, size spread, clumping, tone response, chroma, shadow/highlight response, assumed negative format, monochrome grain, deterministic seed and new-seed action.
- Two selectable render modes:
  - **Correlated field** — multiscale correlated stochastic field; current default.
  - **Particle field · experimental** — thresholded correlated field intended only as a visual experiment. It is NOT the Poisson Boolean disk model in the Python bench and does not claim to simulate silver-halide crystals.
- JPEG export to `Pictures/Emulsion`.

## Scientific status — read before interpreting results
No named-film profile is calibrated. No verified physical scan dataset with known stock, development, scanner optical resolution, scanner linearity and reference patches is included. Consequently, UI parameters are artistic/model controls, not physical measurements. The diameter-to-pixel conversion is only a rough format-based scale estimate; it is not a validated grain-size measurement.

The Android renderer currently uses multiscale random fields and signal-dependent variance. The experimental particle mode is a thresholded field, not a true particle geometry simulator. The research-only Python modules include:
- empirical spatial statistics, autocorrelation and radial/full 2-D PSD diagnostics;
- scanner dark/clear and base-plus-fog calibration path for suitable linear grayscale scans;
- RGB channel covariance diagnostics (not automatic scanner-noise removal);
- independent PSD-controlled spectral Gaussian-field model and fitter;
- inhomogeneous Boolean/Poisson particle model with radius distributions and observation blur;
- synthetic tests and calibration/sample metadata protocols.

These research models are not all ported into Android. In particular, the Python Boolean model and spectral fitter remain research tools. Synthetic self-tests validate software behavior, not physical film fidelity. Do not describe this build as a Tri-X, HP5 or other stock emulation.

## Build Android APK
Open the `Emulsion` directory in Android Studio with JDK 17 and Android SDK Platform 35. Or use the included GitHub Actions workflow at `.github/workflows/android.yml`.

**GitHub repository layout:** extract the contents of this `Emulsion/` directory into the repository root (so `.github/workflows/android.yml`, `settings.gradle.kts`, `build.gradle.kts` and `app/` are directly at repository root). Merely uploading this ZIP as a file will not trigger the workflow inside it. Workflow builds `app/build/outputs/apk/debug/app-debug.apk`.

## Research bench
See `research/README.md` for installation, CLI commands, data semantics and test scope. Main references:
- `research/METHODS_AND_SOURCES.md`
- `research/CALIBRATION_PROTOCOL.md`
- `research/BOOLEAN_MODEL_NOTES.md`
- `research/RESEARCH_PLAN.md`
- `research/EXTERNAL_PROJECT_AUDIT.md`
- `research/PROGRESS_2026-11-08*.md`

## Known Android limitations
- CPU rendering; large images may be slow and memory-intensive.
- Preview is downscaled, export is full resolution; preview and export may differ in texture scale.
- JPEG-only output, no RAW/TIFF/16-bit pipeline, ICC management or metadata preservation.
- Slider updates are debounced but rendering still occurs on a coroutine dispatched to the default pool; this is a prototype, not a performance-optimized production editor.
- No undo/history, crop, masks, presets or named-film profiles.
