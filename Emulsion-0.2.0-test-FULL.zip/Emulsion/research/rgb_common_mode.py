#!/usr/bin/env python3
"""Estimate common RGB density fluctuations and channel-specific residuals.

This is a diagnostic covariance decomposition, not a universal scanner-noise
subtraction. It assumes calibrated density channels with approximately equal
response to a common silver-grain signal and mutually uncorrelated channel-
specific noise. Violations are reported rather than silently corrected.
"""
from __future__ import annotations
import numpy as np


def estimate_common_mode(rgb_density: np.ndarray) -> dict:
    a = np.asarray(rgb_density, dtype=np.float64)
    if a.ndim != 3 or a.shape[-1] != 3:
        raise ValueError('Expected HxWx3 calibrated RGB density array')
    if min(a.shape[:2]) < 8:
        raise ValueError('Patch must be at least 8x8 pixels')
    if not np.all(np.isfinite(a)):
        raise ValueError('Input contains non-finite values')

    # Remove a separate best-fit plane from each channel, preventing a small
    # illumination slope from masquerading as common-mode grain.
    h, w, _ = a.shape
    yy, xx = np.mgrid[:h, :w]
    design = np.column_stack([np.ones(h*w), xx.ravel(), yy.ravel()])
    residuals = []
    for c in range(3):
        y = a[..., c].ravel()
        beta, *_ = np.linalg.lstsq(design, y, rcond=None)
        residuals.append((y - design @ beta).reshape(h, w))
    r = np.stack(residuals, axis=-1)
    flat = r.reshape(-1, 3)
    cov = np.cov(flat, rowvar=False, ddof=1)

    pairs = {
        'RG': float(cov[0, 1]),
        'RB': float(cov[0, 2]),
        'GB': float(cov[1, 2]),
    }
    common = float(np.mean(list(pairs.values())))
    diagonal = np.diag(cov)
    residual_noise = diagonal - common
    corr = np.corrcoef(flat, rowvar=False)
    scale = max(float(np.max(diagonal)), np.finfo(float).eps)
    negative_fraction = float(np.mean(residual_noise < -1e-6 * scale))
    common_inconsistent = common < -1e-6 * scale
    return {
        'method': 'equal-gain common-mode covariance decomposition',
        'assumptions': [
            'RGB channels are calibrated into comparable density units',
            'common silver-image fluctuation has approximately equal gain in all channels',
            'channel-specific scanner noise is mutually uncorrelated',
            'patch contains no residual image texture or local processing artefacts',
        ],
        'covariance_matrix_density2': cov.tolist(),
        'correlation_matrix': corr.tolist(),
        'pairwise_common_covariance_density2': pairs,
        'estimated_common_variance_density2': common,
        'estimated_channel_specific_variance_density2': {
            'R': float(residual_noise[0]),
            'G': float(residual_noise[1]),
            'B': float(residual_noise[2]),
        },
        'common_variance_nonnegative': bool(common >= 0),
        'negative_residual_channel_count': int(np.sum(residual_noise < -1e-6 * scale)),
        'negative_residual_fraction': negative_fraction,
        'diagnostic_warning': (
            'Model assumptions appear inconsistent: estimated common covariance is materially negative.'
            if common_inconsistent else
            'Model assumptions appear inconsistent: one or more residual variances are materially negative.'
            if negative_fraction > 0 else
            'Covariance decomposition is numerically feasible, but assumptions are not proven by this test.'
        ),
        'residual_channel_rms_density': np.sqrt(np.maximum(residual_noise, 0)).tolist(),
        'common_mode_rms_density': float(np.sqrt(max(common, 0))),
        'sample_count': int(h*w),
    }
