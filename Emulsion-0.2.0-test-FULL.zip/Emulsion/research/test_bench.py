import tempfile, unittest
from pathlib import Path
import numpy as np
import tifffile
from bench import (read_image, metrics, make_target, transmittance_to_density, analyze,
                   transmittance_from_scan_signal, circular_aperture_kernel,
                   aperture_filtered_rms)
from boolean_grain_model import render_boolean_grain, boolean_disk_covariance


class BenchTests(unittest.TestCase):
    def test_constant_roi_has_no_corr_length(self):
        m = metrics(np.full((64,64), 0.5))
        self.assertIsNone(m["corr_length_px_1e"])
        self.assertEqual(m["rms_signal"], 0.0)

    def test_white_and_correlated_noise(self):
        rng = np.random.default_rng(42)
        white = rng.normal(size=(256,256))
        k = np.ones((5,5), dtype=float); k /= k.sum()
        from scipy.signal import fftconvolve
        corr = fftconvolve(rng.normal(size=(256,256)), k, mode="same")
        self.assertLessEqual(metrics(white)["corr_length_px_1e"], 3)
        self.assertGreater(metrics(corr)["corr_length_px_1e"], 2)

    def test_16bit_tiff_precision_is_preserved(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/"ramp.tif"
            a = np.array([[1000,1001],[40000,40001]], dtype=np.uint16)
            tifffile.imwrite(p, a)
            loaded = read_image(p, transfer="linear")
            self.assertGreater(loaded[0,1], loaded[0,0])
            self.assertAlmostEqual(loaded[0,0], 1000/65535, places=8)

    def test_psd_has_frequency_axis_when_sampling_known(self):
        rng = np.random.default_rng(7)
        m = metrics(rng.normal(size=(128,128)), px_per_mm=100)
        self.assertTrue(m["frequency_cycles_per_mm"])
        self.assertEqual(m["psd_units"], "signal^2 * mm^2")

    def test_mean_is_reported_before_detrending(self):
        y, x = np.mgrid[:64, :64]
        a = 0.4 + 0.001*x + 0.002*y
        m = metrics(a, detrend="plane")
        self.assertAlmostEqual(m["mean_signal"], float(a.mean()), places=12)
        self.assertLess(m["rms_signal"], 1e-10)

    def test_periodogram_obeys_parseval(self):
        rng = np.random.default_rng(9)
        m = metrics(rng.normal(size=(128, 160)), px_per_mm=157.48)
        self.assertLess(m["psd_parseval_relative_error"], 1e-12)

    def test_transmittance_to_net_density(self):
        d = transmittance_to_density(np.array([0.5, 0.25]), 1.0)
        np.testing.assert_allclose(d, [0.30102999566, 0.60205999133], rtol=1e-9)
        with self.assertRaises(ValueError):
            transmittance_to_density(np.array([0.0]), 1.0)

    def test_analyze_saves_full_2d_spectrum(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d)/"noise.tif"
            out = Path(d)/"out"
            rng = np.random.default_rng(5)
            tifffile.imwrite(src, (rng.random((96,96))*65535).astype(np.uint16))
            analyze(src, out, roi=(0,0,64,64), transfer="linear", px_per_mm=100)
            data = np.load(out/"roi_spatial.npz")
            self.assertIn("gray_psd_2d", data.files)
            self.assertIn("gray_frequency_x", data.files)
            self.assertEqual(data["gray_psd_2d"].shape, (64,64))

    def test_rgb_channels_are_measured_independently(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d)/"rgb.tif"
            rng = np.random.default_rng(123)
            base = rng.normal(0, 0.01, (96,96))
            rgb = np.stack([base, base + rng.normal(0,0.003,(96,96)),
                            rng.normal(0,0.01,(96,96))], axis=-1)
            rgb = np.clip(0.5 + rgb, 0, 1)
            tifffile.imwrite(src, (rgb*65535).astype(np.uint16), photometric="rgb")
            result = analyze(src, Path(d)/"out", roi=(0,0,64,64), transfer="native")
            patch = result["patches"][0]
            self.assertEqual(set(patch["channels"]), {"red", "green", "blue"})
            corr = np.array(patch["cross_channel"]["residual_correlation"])
            self.assertGreater(corr[0,1], corr[0,2])

    def test_constant_float_field_after_plane_detrend_is_zero(self):
        y, x = np.mgrid[:128, :128]
        a = np.full((128,128), 0.9411764705882353) + 1e-16*x
        m = metrics(a, detrend="plane")
        self.assertEqual(m["rms_signal"], 0.0)
        self.assertIsNone(m["corr_length_px_1e"])

    def test_native_transfer_does_not_apply_srgb_curve(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d)/"gray.tif"
            a = np.full((32,32), 32768, dtype=np.uint16)
            tifffile.imwrite(src, a)
            from bench import read_image_data
            native, _ = read_image_data(src, "native")
            linear, _ = read_image_data(src, "srgb")
            self.assertAlmostEqual(float(native.mean()), 32768/65535, places=7)
            self.assertNotAlmostEqual(float(native.mean()), float(linear.mean()), places=3)

    def test_affine_scanner_calibration_recovers_known_net_density(self):
        dark, clear, base_t, net_d = 0.02, 0.98, 0.80, 0.30
        signal_value = dark + (base_t * 10**(-net_d)) * (clear-dark)
        base_signal = dark + base_t * (clear-dark)
        trans = transmittance_from_scan_signal(np.array([signal_value]), dark, clear)
        base_trans = transmittance_from_scan_signal(np.array([base_signal]), dark, clear)[0]
        got = transmittance_to_density(trans, base_trans)
        self.assertAlmostEqual(float(got[0]), net_d, places=12)

    def test_circular_aperture_kernel_is_normalized_and_physical(self):
        k = circular_aperture_kernel(4000/25.4, 48.0)
        self.assertAlmostEqual(float(k.sum()), 1.0, places=12)
        self.assertAlmostEqual(48.0*(4000/25.4)/1000, 7.559055118, places=6)
        self.assertGreater(np.count_nonzero(k), 20)

    def test_aperture_rms_of_constant_density_is_zero(self):
        d = np.full((128,128), 0.75)
        result = aperture_filtered_rms(d, 4000/25.4, 48.0)
        self.assertEqual(result["rms_projection_density"], 0.0)
        self.assertEqual(result["aperture_rms_x1000"], 0.0)

    def test_aperture_rejects_undersampled_geometry(self):
        with self.assertRaises(ValueError):
            circular_aperture_kernel(40, 48.0)

    def test_analyze_reports_calibrated_density_and_aperture_diagnostic(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d)/"calibrated.tif"
            out = Path(d)/"out"
            dark, clear, base_t, net_d = 0.02, 0.98, 0.80, 0.30
            trans = base_t * 10**(-net_d)
            raw = dark + trans*(clear-dark)
            image = np.full((128,128), raw, dtype=np.float64)
            tifffile.imwrite(src, np.round(image*65535).astype(np.uint16))
            # Quantization is the only expected error in this constant-field test.
            base_signal = dark + base_t*(clear-dark)
            result = analyze(src, out, roi=(0,0,128,128), px_per_mm=4000/25.4,
                             transfer="native", density_calibration=(dark,clear,base_signal),
                             aperture_um=48.0)
            patch = result["patches"][0]
            self.assertAlmostEqual(patch["net_projection_density"]["mean_signal"], net_d, delta=0.0002)
            self.assertEqual(patch["aperture_rms"]["interpretation"],
                             "digital circular-aperture equivalent in projection-density units; not ISO diffuse RMS granularity")

    def test_boolean_model_matches_expected_mean_transmittance(self):
        D = np.full((96,96), 0.30)
        result = render_boolean_grain(D, 157.48, mean_radius_um=2.5,
                                      radius_cv=0.3, blur_sigma_um=0.5,
                                      supersample=4, seed=42)
        target = 10**(-0.30)
        self.assertLess(abs(float(result["transmittance"].mean())-target), 0.025)
        self.assertGreater(result["diagnostics"]["grain_count"], 1000)

    def test_boolean_model_is_reproducible_and_zero_density_is_clear(self):
        D = np.zeros((32,32))
        a = render_boolean_grain(D, 157.48, 2.5, seed=99)
        b = render_boolean_grain(D, 157.48, 2.5, seed=99)
        np.testing.assert_array_equal(a["transmittance"], b["transmittance"])
        self.assertEqual(a["diagnostics"]["grain_count"], 0)
        self.assertTrue(np.all(a["transmittance"] == 1.0))

    def test_boolean_covariance_matches_known_limits(self):
        D, r = 0.30, 2.0
        d = np.array([0.0, 1.0, 2.0, 4.0, 5.0])
        c = boolean_disk_covariance(d, D, r)
        T = 10**(-D)
        self.assertAlmostEqual(float(c[0]), T*(1-T), places=12)
        self.assertGreater(c[1], c[2])
        self.assertAlmostEqual(float(c[3]), 0.0, places=12)
        self.assertAlmostEqual(float(c[4]), 0.0, places=12)

    def test_boolean_covariance_rejects_invalid_inputs(self):
        with self.assertRaises(ValueError):
            boolean_disk_covariance(np.array([-1.0]), 0.3, 2.0)
        with self.assertRaises(ValueError):
            boolean_disk_covariance(np.array([1.0]), -0.3, 2.0)

    def test_clipped_lognormal_radius_uses_matching_area_moment(self):
        D = np.full((64,64), 0.25)
        result = render_boolean_grain(D, 1000.0, mean_radius_um=1.0,
                                      radius_cv=1.5, supersample=4, seed=17)
        diag = result["diagnostics"]
        self.assertIn("expected_disk_area_um2_after_radius_cap", diag)
        self.assertNotIn("expected_disk_area_um2_untruncated", diag)
        self.assertLess(abs(diag["output_mean_transmittance"] - 10**(-0.25)), 0.04)


if __name__ == "__main__":
    unittest.main()

class SpectralModelTests(unittest.TestCase):
    def test_spectral_psd_is_finite_and_normalized(self):
        from spectral_grain_model import gaussian_mixture_psd
        p = gaussian_mixture_psd((128, 160), 4000, (2, 8), (0.7, 0.3), 0.01)
        self.assertTrue(np.all(np.isfinite(p)))
        self.assertAlmostEqual(float(p.mean()), 1.0, places=12)
        self.assertTrue(np.all(p >= 0))

    def test_spectral_field_is_reproducible_and_unit_variance(self):
        from spectral_grain_model import synthesize_unit_field
        a, _ = synthesize_unit_field((128, 128), 4000, seed=42)
        b, _ = synthesize_unit_field((128, 128), 4000, seed=42)
        c, _ = synthesize_unit_field((128, 128), 4000, seed=43)
        self.assertTrue(np.array_equal(a, b))
        self.assertFalse(np.array_equal(a, c))
        self.assertAlmostEqual(float(a.std()), 1.0, places=12)
        self.assertAlmostEqual(float(a.mean()), 0.0, places=12)

    def test_density_sigma_interpolation(self):
        from spectral_grain_model import density_sigma
        got = density_sigma(np.array([0, .25, .5, 1.5, 3]), [0, 1, 2], [0, .02, .01])
        np.testing.assert_allclose(got, [0, .005, .01, .015, .01])

    def test_rendered_density_uses_density_dependent_sigma(self):
        from spectral_grain_model import render_spectral_density
        d = np.tile(np.array([0.25, 0.75, 1.25, 1.75]), (128, 32))
        r = render_spectral_density(d, 4000, [0, 1, 2], [0.005, 0.02, 0.01], seed=9)
        self.assertEqual(r['density'].shape, d.shape)
        self.assertAlmostEqual(float(r['residual'].std()), float(r['diagnostics']['residual_std']), places=12)
        self.assertGreater(float(r['residual'].std()), 0)

    def test_fit_recovers_synthetic_psd_shape(self):
        from spectral_grain_model import fit_gaussian_mixture_psd
        f = np.linspace(0, 500, 100)
        raw = .65*np.exp(-2*np.pi**2*(2.0/1000)**2*f**2) + .35*np.exp(-2*np.pi**2*(9.0/1000)**2*f**2) + .01
        raw /= raw.mean()
        fit = fit_gaussian_mixture_psd(f, raw)
        self.assertTrue(fit['success'])
        self.assertLess(fit['log_rmse'], 0.05)

    def test_spectral_model_rejects_negative_net_density(self):
        from spectral_grain_model import render_spectral_density
        with self.assertRaises(ValueError):
            render_spectral_density(np.full((32,32), -0.1), 4000, [0,1], [0.01,0.02])
