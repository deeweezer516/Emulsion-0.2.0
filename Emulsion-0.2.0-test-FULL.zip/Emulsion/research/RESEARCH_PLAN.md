# Emulsion: research and calibration plan

## Stage A — measurement harness
The v0.4 bench is a first-pass tool for scan-domain statistics, not an ISO instrument. It preserves integer TIFF precision, analyzes ROIs, computes RMS/variance, overlap-corrected autocorrelation and a Hann-windowed 2D periodogram, and includes synthetic validation. See `METHODS_AND_SOURCES.md`.

## Stage B — physical B&W reference data
Start with Kodak TRI-X 400 and Ilford HP5 Plus, but keep film stock, format, batch, exposure and development process distinct. Kodak F-4017 gives one qualified manufacturer RMS anchor for Tri-X (17 at net diffuse density 1.0, 48 µm aperture, 12×); Kodak explicitly describes the legacy-to-current version caveat. The official HP5+ sheet inspected here has no RMS/granularity datum, so HP5 remains qualitative until a verified measurement or physical sample is available.

## Stage C — physical sample acquisition
For each stock/process:
- at least 3 independent frames or separately exposed samples;
- at least 5 net-density levels;
- multiple non-overlapping ROIs per density;
- 16-bit master scans and optical sampling in pixels/mm;
- scanner noise and MTF characterized separately;
- no sharpening, grain reduction, auto contrast, dust-removal or resizing in the master;
- metadata complete enough to reproduce exposure and processing;
- at least one held-out sample/frame for validation.

A display calibration target alone is not a film exposure target. For film, use a calibrated step wedge or uniform exposure fields on film; a photographed printed target has its own printer/paper/illumination MTF and tone response.

## Stage D — model
For B&W, evaluate a signal-dependent random-dot / particle-field model with development spread and optical/scanner blur as separate stages. A filtered Gaussian model can be a faster approximation if fitted against measured variance and 2D NPS across density and magnification. Do not claim the dots are literal microscopic crystallites absent microscopy evidence.

## Stage E — Android integration
Only after the offline model has passed quantitative and visual holdout tests:
- implement a deterministic, tileable / memory-bounded renderer;
- preserve full-resolution export;
- add stock profiles with explicit parameter provenance;
- compare Android output against reference render and ensure no seams or resolution-dependent shifts.

## Stop/go criteria
1. Scanner contribution and tone response characterized.
2. Multiple independent samples and density levels measured.
3. Density-dependent variance/RMS and 2D PSD matched, not just one RMS scalar.
4. Correct behavior under changes in magnification and optical blur.
5. Held-out sample predictions within declared tolerances.
6. Every profile parameter tagged measured, literature, fitted or assumed.


Current v0.4 additionally preserves native scan encoding by default, measures RGB channels independently, records basic TIFF metadata and reports cross-channel covariance without subtracting scanner noise. See CALIBRATION_PROTOCOL.md for acceptance gates.
