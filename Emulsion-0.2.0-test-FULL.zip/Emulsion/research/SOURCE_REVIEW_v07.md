# Source review — 0.7

## ISO 10505:2009

Official ISO page: https://committee.iso.org/cms/live/live/en/sites/isoorg/contents/data/standard/05/07/50747.html

The page states that ISO 10505 determines intrinsic RMS granularity caused
solely by developed image-forming centres; it applies to continuous-tone
monochrome silver-absorbing and colour dye-absorbing materials on transmitting
support, with viewing magnifications 5x–12x. It explicitly says estimation of
the Wiener/noise power spectrum is outside its scope. The ISO page says the
2009 edition was reviewed and confirmed in 2025.

## Newson, Faraj, Delon & Galerne (2017)

Open article: https://www.ipol.im/pub/art/2017/192/article_lr.pdf
Project page: https://www.ipol.im/pub/art/2017/192/

Relevant sections checked directly:

- §2 describes gelatin with photosensitive silver-halide crystals; exposure
  creates developable centres and development produces opaque developed
  grains. The paper's binary model is a simplifying representation of this
  process, not a complete chemical/physical emulsion simulation.
- §3.1 defines an inhomogeneous Boolean model from Poisson-distributed disk
  centres with a radius distribution and density-dependent intensity.
- §3.2 applies a Gaussian observation filter to the binary random set.
- §4 describes grain-wise and pixel-wise Monte Carlo renderers and their
  computational tradeoffs.
- §5.4 states limitations: some emulsions are difficult to emulate; dark areas
  can look unrealistic when only a few grains occur; runtime is far from
  real-time in the reported implementation. Figure 10 illustrates that their
  Boolean model does not reproduce the bright/“white” grain tendency in the
  cited Ilford Delta 3200 example.
- §5.2's colour-channel independence is presented as an approximation based
  on the layered silver-halide colour-film structure, not a dye-cloud model
  calibrated from colour negative measurements.

## Historical Wiener spectrum evidence

Takano (1968/1969), “Granularity of Photographic Image (II): Wiener Spectrum
at a Constant Density Level with Various Exposure and Time of Development”,
J-STAGE: https://www.jstage.jst.go.jp/article/photogrst1964/31/4/31_4_209/_article/-char/en

The abstract reports that, at equal density, spectrum level and expected
mottle size varied with exposure/development combinations; higher exposure
and shorter development time produced larger spectrum level and expected
mottle size in the tested conditions. This is a useful warning: equal optical
density alone does not uniquely determine granularity. It is not a Tri-X
profile and the specific stock/process must not be inferred from this paper.
