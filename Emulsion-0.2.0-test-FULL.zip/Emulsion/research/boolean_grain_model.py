#!/usr/bin/env python3
"""Experimental inhomogeneous Boolean grain model (research reference only).

The model follows the random-set construction described by Newson et al. (2017):
Poisson-distributed disk centers, a radius distribution, signal-dependent intensity,
and a separate observation blur. It is NOT a calibrated profile for any film stock.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
from scipy.ndimage import gaussian_filter
from scipy.special import ndtr
from PIL import Image


def _lognormal_parameters(mean: float, cv: float):
    if mean <= 0 or not np.isfinite(mean):
        raise ValueError("mean_radius_um must be finite and > 0")
    if cv < 0 or not np.isfinite(cv):
        raise ValueError("radius_cv must be finite and >= 0")
    if cv == 0:
        return None, None
    sigma = np.sqrt(np.log1p(cv * cv))
    mu = np.log(mean) - 0.5 * sigma * sigma
    return mu, sigma


def boolean_disk_covariance(distance_um, net_projection_density: float,
                             radius_um: float) -> np.ndarray:
    """Analytic covariance of the *unfiltered continuous* Boolean disk field.

    Returns covariance of the uncovered/transmittance indicator at separation
    ``distance_um`` for a homogeneous Poisson Boolean model with fixed disk
    radius. This is a theory reference, not a scanner-domain NPS prediction.
    At distances >= 2r the two influence disks do not overlap and covariance
    is zero. At zero separation it is T(1-T), where T=10**(-D).
    """
    d = np.asarray(distance_um, dtype=np.float64)
    D = float(net_projection_density)
    r = float(radius_um)
    if np.any(~np.isfinite(d)) or np.any(d < 0):
        raise ValueError("distance_um must be finite and >= 0")
    if not np.isfinite(D) or D < 0:
        raise ValueError("net_projection_density must be finite and >= 0")
    if not np.isfinite(r) or r <= 0:
        raise ValueError("radius_um must be finite and > 0")
    if D == 0:
        return np.zeros_like(d)
    area = np.pi * r * r
    lam = np.log(10.0) * D / area
    overlap = np.zeros_like(d)
    inside = d < 2.0 * r
    di = d[inside]
    overlap[inside] = (2.0 * r*r * np.arccos(np.clip(di/(2.0*r), -1.0, 1.0))
                       - 0.5 * di * np.sqrt(np.maximum(4.0*r*r-di*di, 0.0)))
    union_area = 2.0 * area - overlap
    cov = np.exp(-lam * union_area) - np.exp(-2.0 * lam * area)
    return np.maximum(cov, 0.0)


def render_boolean_grain(
    net_projection_density,
    px_per_mm: float,
    mean_radius_um: float,
    radius_cv: float = 0.35,
    blur_sigma_um: float = 0.0,
    supersample: int = 4,
    seed: int = 1,
    max_grains: int = 1_000_000,
):
    """Render a B&W opaque-disk Boolean grain field from net projection density.

    Assumptions and interpretation:
      * Input D is calibrated net projection density, not arbitrary display luminance.
      * An uncovered point transmits 1; a covered point transmits 0.
      * For a homogeneous Poisson Boolean model, E[T] = exp(-lambda E[A]);
        setting lambda = ln(10)*D/E[A] therefore targets mean transmittance 10**(-D).
      * Disk radii are log-normal (or constant if radius_cv=0), clipped at the
        99.99th percentile for finite rendering bounds.
      * Gaussian blur is an explicit observation-stage approximation, not a
        scanner-specific MTF or a literal emulsion-development model.

    Returns a dict with coverage, negative transmittance and model diagnostics.
    """
    D = np.asarray(net_projection_density, dtype=np.float64)
    if D.ndim != 2 or min(D.shape) < 16:
        raise ValueError("input density must be a 2D array at least 16x16")
    if np.any(~np.isfinite(D)) or np.any(D < 0):
        raise ValueError("net projection density must be finite and >= 0")
    px_per_mm = float(px_per_mm)
    blur_sigma_um = float(blur_sigma_um)
    if not np.isfinite(px_per_mm) or px_per_mm <= 0:
        raise ValueError("px_per_mm must be finite and > 0")
    if not np.isfinite(blur_sigma_um) or blur_sigma_um < 0:
        raise ValueError("blur_sigma_um must be finite and >= 0")
    if supersample not in (2, 4, 8):
        raise ValueError("supersample must be 2, 4, or 8")
    if max_grains < 1:
        raise ValueError("max_grains must be >= 1")

    pixel_pitch_um = 1000.0 / px_per_mm
    mu_log, sigma_log = _lognormal_parameters(mean_radius_um, radius_cv)
    if radius_cv == 0:
        radius_cap = mean_radius_um
        expected_r2 = mean_radius_um**2
    else:
        # The renderer uses min(R, cap), not an unbounded log-normal draw.
        # Match the Poisson intensity to E[min(R, cap)^2], otherwise the
        # target mean transmittance is biased for large radius CV values.
        z_cap = 3.719016485  # standard-normal 99.99th percentile
        radius_cap = float(np.exp(mu_log + z_cap * sigma_log))
        z2 = (np.log(radius_cap) - mu_log - 2.0 * sigma_log**2) / sigma_log
        p_tail = 1.0 - ndtr(z_cap)
        truncated_second_moment = np.exp(2.0 * mu_log + 2.0 * sigma_log**2) * ndtr(z2)
        expected_r2 = float(truncated_second_moment + radius_cap**2 * p_tail)
    expected_disk_area_um2 = np.pi * expected_r2

    margin_um = radius_cap + 3.0 * blur_sigma_um + pixel_pitch_um
    margin_px = int(np.ceil(margin_um / pixel_pitch_um))
    padded = np.pad(D, margin_px, mode="edge")

    # E[covered] = 1 - exp(-lambda * E[disk area]); target T=10**(-D).
    lam_per_um2 = np.log(10.0) * padded / expected_disk_area_um2
    counts = np.random.default_rng(seed).poisson(lam_per_um2 * pixel_pitch_um**2)
    total = int(counts.sum())
    if total > max_grains:
        raise ValueError(
            f"model requires {total:,} grains, exceeding max_grains={max_grains:,}; "
            "use a smaller ROI, larger mean radius, or a higher max_grains limit"
        )

    rng = np.random.default_rng(seed + 1)
    yy_cells, xx_cells = np.nonzero(counts)
    cell_counts = counts[yy_cells, xx_cells]
    if total:
        grain_y = np.repeat(yy_cells, cell_counts)
        grain_x = np.repeat(xx_cells, cell_counts)
        center_x = (grain_x + rng.random(total)) * supersample
        center_y = (grain_y + rng.random(total)) * supersample
        if radius_cv == 0:
            radii_um = np.full(total, mean_radius_um, dtype=np.float64)
        else:
            radii_um = rng.lognormal(mu_log, sigma_log, total)
            radii_um = np.minimum(radii_um, radius_cap)
        radii_hi = radii_um / pixel_pitch_um * supersample
    else:
        center_x = center_y = radii_hi = np.empty(0, dtype=np.float64)

    ph, pw = padded.shape
    hi_h, hi_w = ph * supersample, pw * supersample
    mask = np.zeros((hi_h, hi_w), dtype=np.uint8)
    # Draw each opaque grain into a supersampled binary random set.
    for cx, cy, radius in zip(center_x, center_y, radii_hi):
        x0 = max(0, int(np.floor(cx - radius - 0.5)))
        x1 = min(hi_w, int(np.ceil(cx + radius - 0.5)) + 1)
        y0 = max(0, int(np.floor(cy - radius - 0.5)))
        y1 = min(hi_h, int(np.ceil(cy + radius - 0.5)) + 1)
        if x0 >= x1 or y0 >= y1:
            continue
        xs = np.arange(x0, x1, dtype=np.float64) + 0.5
        ys = np.arange(y0, y1, dtype=np.float64) + 0.5
        disk = (ys[:, None] - cy)**2 + (xs[None, :] - cx)**2 <= radius**2
        view = mask[y0:y1, x0:x1]
        view[disk] = 1

    sigma_hi = blur_sigma_um / pixel_pitch_um * supersample
    if sigma_hi > 0:
        observed = gaussian_filter(mask.astype(np.float32), sigma=sigma_hi, mode="reflect")
    else:
        observed = mask.astype(np.float32)
    coverage_hi = observed.reshape(ph, supersample, pw, supersample).mean(axis=(1, 3))
    coverage_hi = np.clip(coverage_hi, 0.0, 1.0)
    coverage = coverage_hi[margin_px:-margin_px, margin_px:-margin_px]
    transmittance = np.clip(1.0 - coverage, 0.0, 1.0)

    return {
        "coverage": coverage,
        "transmittance": transmittance,
        "diagnostics": {
            "model": "inhomogeneous Boolean disks; experimental reference implementation",
            "seed": int(seed),
            "grain_count": total,
            "pixel_pitch_um": pixel_pitch_um,
            "mean_radius_um": float(mean_radius_um),
            "radius_cv": float(radius_cv),
            "radius_cap_um_99_99pct": float(radius_cap),
            "expected_disk_area_um2_after_radius_cap": float(expected_disk_area_um2),
            "blur_sigma_um": blur_sigma_um,
            "supersample": int(supersample),
            "input_mean_transmittance_target": float(np.mean(10.0**(-D))),
            "output_mean_transmittance": float(np.mean(transmittance)),
            "warning": "un-calibrated research model; not a measured Tri-X/HP5 profile or a literal microcrystal model"
        }
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--density", required=True, help="NumPy .npy array containing calibrated net projection density")
    ap.add_argument("--out", required=True, help="Output 16-bit TIFF of simulated negative transmittance")
    ap.add_argument("--px-per-mm", type=float, required=True)
    ap.add_argument("--mean-radius-um", type=float, required=True)
    ap.add_argument("--radius-cv", type=float, default=0.35)
    ap.add_argument("--blur-sigma-um", type=float, default=0.0)
    ap.add_argument("--supersample", type=int, choices=[2,4,8], default=4)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--max-grains", type=int, default=1_000_000)
    args = ap.parse_args()
    D = np.load(args.density)
    result = render_boolean_grain(D, args.px_per_mm, args.mean_radius_um,
                                  args.radius_cv, args.blur_sigma_um,
                                  args.supersample, args.seed, args.max_grains)
    trans = result["transmittance"]
    out = Path(args.out); out.parent.mkdir(parents=True, exist_ok=True)
    np.save(out.with_suffix(".npy"), trans.astype(np.float32))
    Image.fromarray(np.round(np.clip(trans, 0, 1) * 65535).astype(np.uint16)).save(out)
    out.with_suffix(".json").write_text(__import__("json").dumps(result["diagnostics"], indent=2))
    print(__import__("json").dumps(result["diagnostics"], indent=2))


if __name__ == "__main__":
    main()
