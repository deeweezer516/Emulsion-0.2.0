# Experimental Boolean grain model — v0.6

## Purpose

`boolean_grain_model.py` is a small, independent research implementation of an inhomogeneous Boolean random-set model inspired by Newson, Faraj, Delon and Galerne (2017). It is a candidate mathematical baseline for black-and-white grain, not a calibrated film stock profile and not an Android production implementation.

## Construction

For a locally uniform negative with calibrated net projection density `D`, opaque disk grains are placed with Poisson-distributed centers. If disk radii are random, their expected area is `E[A] = π E[R²]`. For a homogeneous Poisson Boolean model, the probability that a point remains uncovered is:

`P(uncovered) = exp(-λ E[A])`.

Setting the target mean transmittance to `T = 10^(-D)` gives:

`λ = -ln(T) / E[A] = ln(10) D / E[A]`.

The code uses either constant radii or a log-normal radius distribution parameterized by arithmetic mean radius and coefficient of variation. It then rasterizes the union of opaque disks at a supersampled resolution, optionally applies a Gaussian observation blur, and area-averages to the requested scan grid.

The renderer outputs negative transmittance (`1 - coverage`), not optical density after filtering. This is deliberate: converting fully covered pixels to `-log10(T)` can create unbounded density spikes in a binary opaque-disk model. The mean transmittance, rather than mean density, is the quantity this construction is designed to preserve in expectation for a flat field.

## Assumptions and limitations

- Grain shapes are 2-D opaque disks. Actual photographic image-forming structures are not literally identical opaque disks; this is a stochastic geometric abstraction.
- The input must be calibrated net projection density. Arbitrary sRGB photos or positive images are not valid inputs without a separate tone-to-negative-density mapping.
- The mean-transmittance result is exact in expectation for a homogeneous field before finite rasterization. Spatially varying density is a local-intensity approximation because grains can overlap across tone boundaries.
- The radius distribution and Gaussian blur are exposed parameters, but no Tri-X or HP5 values have been measured for them.
- The 99.99th-percentile radius cap is a finite-rendering approximation; its effect is negligible for ordinary CV values but is recorded in diagnostics.
- The Gaussian blur is not a measured scanner MTF, print MTF, or ISO microdensitometer transfer function.
- The model does not simulate exposure statistics, latent-image formation, development chemistry, crystal morphology, adjacency effects, halide solvent action, gelatin swelling, or film-layer structure.
- No stock profile is generated and no Android source is changed until measured scans constrain the parameters and held-out validation passes.

## Current synthetic checks

The automated suite checks that a flat field at `D = 0.30` has output mean transmittance close to `10^-0.30`, that the result is reproducible for a fixed seed, and that `D = 0` produces a clear field with no grains. These are mathematical self-consistency tests, not validation against photographic film.

## Reference

A. Newson, N. Faraj, J. Delon, B. Galerne, “Realistic Film Grain Rendering,” *Image Processing On Line*, 7 (2017), 165–183. DOI: https://doi.org/10.5201/ipol.2017.192. The paper describes an inhomogeneous Boolean model with Poisson grain centers, a radius distribution, signal-dependent intensity and a subsequent observation filter. The published IPOL implementation is GPL-3.0-or-later; this file is an independent implementation from the published mathematical description and does not copy source code.

## v0.7 audit additions

The implementation now includes an analytic covariance reference for the homogeneous fixed-radius Boolean disk model. For two locations separated by distance `h`, the covariance of the uncovered/transmittance indicator is

`Cov[U(0), U(h)] = exp(-lambda * |B_r(0) union B_r(h)|) - exp(-2 lambda pi r^2)`.

For `h = 0`, this reduces to `T(1-T)` where `T = 10^(-D)`. For `h >= 2r`, it is exactly zero for fixed-radius disks. This provides an independent theoretical check on future empirical autocorrelation and NPS work. It is not the covariance of the filtered, rasterized, scanner-observed output; pixel integration, supersampling, blur and scanner MTF must be applied before comparing to scan-domain measurements.

A second audit found a parameter-consistency issue: the renderer clips log-normal radii at the 99.99th percentile but previously calculated Poisson intensity using the *unclipped* second moment. For large radius coefficient of variation this makes the simulated mean transmittance systematically brighter than its declared target. The intensity is now based on `E[min(R, cap)^2]`, matching the actual clipped radius distribution. This matters little for ordinary low-CV profiles but prevents a known bias for broad distributions.

## Important limitation confirmed in the primary paper

Newson et al. explicitly state that the Boolean model cannot reproduce emulsions whose characteristic appearance includes bright/"white" grains (their Ilford Delta 3200 comparison, Figure 10). They also identify unrealistic behavior in dark areas when only a few grains are present and note the computational cost. Therefore this model is retained only as a black-grain baseline. A later model branch must allow signed/dual-polarity structures or another empirically justified representation; we must not claim that tuning disk radius and blur can cover all B&W stocks.
