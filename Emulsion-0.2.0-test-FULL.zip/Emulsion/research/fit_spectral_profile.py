#!/usr/bin/env python3
"""Fit the empirical two-scale PSD shape to a bench *_spatial.npz file.

Requires a calibrated px/mm analysis. The fit is a phenomenological spectrum
summary, not a physical grain-size measurement.
"""
import argparse, json
from pathlib import Path
import numpy as np
from spectral_grain_model import fit_gaussian_mixture_psd


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--npz',required=True)
    ap.add_argument('--channel',default='gray')
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    z=np.load(args.npz)
    psd=z[f'{args.channel}_psd_2d']
    fx=z[f'{args.channel}_frequency_x']; fy=z[f'{args.channel}_frequency_y']
    if psd.size==0 or fx.size==0 or fy.size==0:
        raise SystemExit('This NPZ has no physical-frequency PSD. Re-run bench analysis with a verified px/mm value.')
    yy,xx=np.meshgrid(fy,fx,indexing='ij')
    rr=np.sqrt(xx*xx+yy*yy)
    # Average opposite frequencies together; omit the DC bin.
    df=max(np.median(np.diff(np.sort(np.unique(np.abs(fx))))),
           np.median(np.diff(np.sort(np.unique(np.abs(fy))))))
    bins=np.arange(0, min(np.max(np.abs(fx)),np.max(np.abs(fy)))+df, df)
    ids=np.digitize(rr.ravel(),bins)
    p=psd.ravel()
    fmid=(bins[:-1]+bins[1:])/2
    radial=np.array([np.mean(p[ids==i]) if np.any(ids==i) else np.nan for i in range(1,len(bins))])
    valid=np.isfinite(radial)&(radial>=0)
    fit=fit_gaussian_mixture_psd(fmid[valid],radial[valid])
    result={'source_npz':str(args.npz),'channel':args.channel,'fit':fit,
            'interpretation':'radial PSD shape fit only; no density-dependent variance fit and no physical grain-size inference'}
    out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
