#!/usr/bin/env python3
"""Emulsion Research Bench v0.4: reproducible image-texture measurements.

Measurements describe the supplied scan/render pipeline, not isolated emulsion
particles. Density calibration and scanner characterization are separate tasks.
"""
import argparse, csv, json, warnings
from pathlib import Path
import numpy as np
from PIL import Image
import tifffile
from scipy import signal
from scipy import ndimage
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def srgb_to_linear(x):
    x = np.asarray(x, dtype=np.float64)
    return np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4)


def make_target(out, size=2048, bit_depth=16):
    if size < 512:
        raise ValueError("size must be >= 512")
    h = w = int(size)
    maxv = 65535 if bit_depth == 16 else 255
    levels8 = [16, 64, 128, 192, 240]
    levels = np.round(np.array(levels8) / 255 * maxv).astype(np.uint16 if bit_depth == 16 else np.uint8)
    im = np.zeros((h, w), dtype=np.uint16 if bit_depth == 16 else np.uint8)
    for i, v in enumerate(levels):
        im[:, i*w//5:(i+1)*w//5] = v
    gh = max(1, h // 5)
    grad = np.linspace(0, maxv, w).round().astype(im.dtype)[None, :]
    im[-gh:, :] = np.repeat(grad, gh, axis=0)
    band = max(24, h // 24)
    y0 = h - gh - band
    yy, xx = np.mgrid[0:band, 0:w]
    edge = (xx > (w//2 + (yy-band/2)*0.35)).astype(im.dtype) * maxv
    im[y0:y0+band, :] = edge
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    tifffile.imwrite(out, im, photometric="minisblack") if str(out).lower().endswith((".tif", ".tiff")) else Image.fromarray((im / (maxv/255)).round().astype(np.uint8)).save(out)
    return levels8


def _load_array(path):
    """Load numeric pixels and report container metadata without assuming scan linearity."""
    path = str(path)
    metadata = {"path": path, "container_dtype": None, "significant_bits": None,
                "tiff_resolution": None, "tiff_resolution_unit": None,
                "software": None, "icc_profile_present": False}
    if path.lower().endswith((".tif", ".tiff")):
        with tifffile.TiffFile(path) as tf:
            page = tf.pages[0]
            a = page.asarray()
            metadata["container_dtype"] = str(a.dtype)
            try:
                bps = page.tags.get("BitsPerSample")
                if bps is not None:
                    val = bps.value
                    metadata["significant_bits"] = int(val[0] if isinstance(val, tuple) else val)
            except Exception:
                pass
            for tag_name, key in (("XResolution", "x_resolution"), ("YResolution", "y_resolution"),
                                  ("ResolutionUnit", "resolution_unit"), ("Software", "software")):
                tag = page.tags.get(tag_name)
                if tag is not None:
                    val = tag.value
                    if hasattr(val, 'numerator') and hasattr(val, 'denominator'):
                        val = float(val)
                    metadata[key] = str(val) if key in ("software", "resolution_unit") else val
            metadata["tiff_resolution"] = [metadata.get("x_resolution"), metadata.get("y_resolution")]
            metadata["tiff_resolution_unit"] = metadata.get("resolution_unit")
            metadata["icc_profile_present"] = page.tags.get("InterColorProfile") is not None
    else:
        with Image.open(path) as im:
            a = np.asarray(im)
            metadata["container_dtype"] = str(a.dtype)
            metadata["icc_profile_present"] = bool(im.info.get("icc_profile"))
            metadata["image_mode"] = im.mode
    if a.ndim == 3 and a.shape[-1] == 4:
        a = a[..., :3]
    if a.ndim == 3 and a.shape[-1] not in (1, 3):
        raise ValueError(f"Unsupported image shape {a.shape}; expected grayscale or RGB(A).")
    if a.ndim == 3 and a.shape[-1] == 1:
        a = a[..., 0]
    if a.ndim not in (2,3):
        raise ValueError(f"Unsupported image shape {a.shape}; expected 2D grayscale or 3D RGB.")
    if np.issubdtype(a.dtype, np.integer):
        bits = metadata.get("significant_bits") or (np.iinfo(a.dtype).bits)
        scale = float((1 << int(bits)) - 1)
        metadata["normalization_max"] = scale
        a = a.astype(np.float64) / scale
    else:
        a = a.astype(np.float64)
        if np.nanmax(a) > 1.0 or np.nanmin(a) < 0:
            raise ValueError("Floating-point images must be normalized to [0, 1].")
    if not np.all(np.isfinite(a)):
        raise ValueError("Image contains NaN or infinite values.")
    return a, metadata


def read_image_data(path, transfer="native"):
    """Return grayscale/RGB channels. 'native' preserves encoded scan values."""
    a, metadata = _load_array(path)
    if transfer == "srgb":
        a = srgb_to_linear(a)
    elif transfer not in ("linear", "native"):
        raise ValueError("transfer must be native, linear, or srgb")
    metadata["transfer_applied"] = transfer
    return a, metadata


def read_image(path, transfer="native"):
    """Compatibility helper: return grayscale or Rec.709 luma after selected transfer."""
    a, _ = read_image_data(path, transfer)
    if a.ndim == 2:
        return a
    # This luma conversion is only a convenience view; RGB measurement uses channels separately.
    return 0.2126*a[..., 0] + 0.7152*a[..., 1] + 0.0722*a[..., 2]

def radial_mean(arr, bin_width=1.0):
    h, w = arr.shape
    cy, cx = h//2, w//2
    y, x = np.ogrid[:h, :w]
    r = np.sqrt((y-cy)**2 + (x-cx)**2)
    bins = np.floor(r / bin_width).astype(int)
    sums = np.bincount(bins.ravel(), weights=arr.ravel())
    counts = np.bincount(bins.ravel())
    return sums / np.maximum(counts, 1)


def detrend_patch(p, mode="plane"):
    """Remove constant or planar background without changing the reported raw mean."""
    p = np.asarray(p, dtype=np.float64)
    if mode == "none":
        return p.copy()
    if mode == "constant":
        return p - np.mean(p)
    if mode != "plane":
        raise ValueError("detrend must be none, constant, or plane")
    h, w = p.shape
    yy, xx = np.mgrid[-1:1:complex(h), -1:1:complex(w)]
    design = np.column_stack((np.ones(p.size), xx.ravel(), yy.ravel()))
    coeff, *_ = np.linalg.lstsq(design, p.ravel(), rcond=None)
    trend = (coeff[0] + coeff[1]*xx + coeff[2]*yy)
    return p - trend


def transmittance_from_scan_signal(signal_values, dark_signal, clear_signal):
    """Linearize an already-linear scanner signal using measured dark/clear references.

    This is an affine calibration only. It does not repair nonlinear scanner response,
    gamma encoding, automatic exposure, channel mixing, or flare.
    """
    s = np.asarray(signal_values, dtype=np.float64)
    dark, clear = float(dark_signal), float(clear_signal)
    if not np.isfinite(dark) or not np.isfinite(clear) or clear <= dark:
        raise ValueError("clear_signal must be finite and greater than dark_signal")
    if np.any(~np.isfinite(s)):
        raise ValueError("scan signal must be finite")
    t = (s - dark) / (clear - dark)
    if np.any(t <= 0):
        raise ValueError("calibrated transmittance must be > 0; check dark/clear references")
    return t


def transmittance_to_density(transmittance, base_transmittance):
    """Convert linear transmittance to net optical density above base+fog."""
    t = np.asarray(transmittance, dtype=np.float64)
    tb = float(base_transmittance)
    if not np.isfinite(tb) or tb <= 0:
        raise ValueError("base_transmittance must be finite and > 0")
    if np.any(~np.isfinite(t)) or np.any(t <= 0):
        raise ValueError("transmittance must contain finite values > 0")
    return -np.log10(t / tb)


def circular_aperture_kernel(px_per_mm, diameter_um=48.0):
    """Create a sampled, area-normalized circular aperture kernel.

    This models only the geometric aperture. It does NOT reproduce the full
    ISO microdensitometer optics/illumination/MTF/electronics.
    """
    px_per_mm = float(px_per_mm)
    diameter_um = float(diameter_um)
    if not np.isfinite(px_per_mm) or px_per_mm <= 0:
        raise ValueError("px_per_mm must be finite and > 0")
    if not np.isfinite(diameter_um) or diameter_um <= 0:
        raise ValueError("diameter_um must be finite and > 0")
    diameter_px = diameter_um * px_per_mm / 1000.0
    if diameter_px < 4.0:
        raise ValueError(
            f"aperture is only {diameter_px:.2f} pixels wide; need >=4 pixels "
            "for a minimally sampled digital aperture"
        )
    radius = diameter_px / 2.0
    half = int(np.ceil(radius + 0.5))
    yy, xx = np.mgrid[-half:half+1, -half:half+1]
    # Supersampling improves the area estimate for the circular boundary.
    sub = 8
    offsets = (np.arange(sub) + 0.5) / sub - 0.5
    coverage = np.zeros(xx.shape, dtype=np.float64)
    for oy in offsets:
        for ox in offsets:
            coverage += ((xx + ox)**2 + (yy + oy)**2 <= radius**2)
    kernel = coverage / (sub * sub)
    total = kernel.sum()
    if total <= 0:
        raise ValueError("aperture kernel has zero area")
    return kernel / total


def aperture_filtered_rms(density, px_per_mm, diameter_um=48.0, detrend="plane"):
    """Approximate RMS density after a circular digital aperture average.

    Result is an aperture-equivalent diagnostic, not an ISO 10505 measurement.
    """
    d = np.asarray(density, dtype=np.float64)
    if d.ndim != 2 or min(d.shape) < 32:
        raise ValueError("density ROI must be 2D and at least 32x32 pixels")
    kernel = circular_aperture_kernel(px_per_mm, diameter_um)
    filtered = ndimage.convolve(d, kernel, mode="reflect")
    margin = kernel.shape[0] // 2
    if min(filtered.shape) <= 2 * margin:
        raise ValueError("ROI is too small for the selected aperture")
    valid = filtered[margin:-margin, margin:-margin]
    residual = detrend_patch(valid, detrend)
    variance = float(np.mean(residual * residual))
    if variance <= 1e-24 * max(float(np.mean(valid * valid)), 1.0):
        variance = 0.0
    sigma = float(np.sqrt(variance))
    return {
        "aperture_diameter_um": float(diameter_um),
        "aperture_diameter_px": float(diameter_um * px_per_mm / 1000.0),
        "rms_projection_density": sigma,
        "aperture_rms_x1000": sigma * 1000.0,
        "interpretation": "digital circular-aperture equivalent in projection-density units; not ISO diffuse RMS granularity"
    }


def metrics(patch, px_per_mm=None, detrend="plane"):
    raw = np.asarray(patch, dtype=np.float64)
    if raw.ndim != 2 or min(raw.shape) < 16:
        raise ValueError("ROI must be a 2D image at least 16x16 pixels.")
    mean_signal = float(np.mean(raw))
    p = detrend_patch(raw, detrend)
    var = float(np.mean(p*p))
    if var <= 1e-24 * max(float(np.mean(raw*raw)), 1.0):
        p = np.zeros_like(p)
        var = 0.0
    rms = float(np.sqrt(var))
    if var == 0.0:
        return {
            "mean_signal": mean_signal, "rms_signal": rms,
            "variance_signal": var, "corr_length_px_1e": None,
            "corr_length_mm_1e": None, "psd_units": "not defined for zero-variance ROI",
            "autocorrelation_radial": [], "psd_radial": [], "frequency_cycles_per_mm": [],
            "autocorrelation_2d": np.zeros((0,0)), "psd_2d": np.zeros((0,0)),
            "frequency_x": np.array([]), "frequency_y": np.array([])
        }

    h, w = p.shape
    # Unbiased spatial autocovariance: normalize by number of overlapping pairs.
    acov = signal.fftconvolve(p, p[::-1, ::-1], mode="full")
    yy = np.arange(-(h-1), h)
    xx = np.arange(-(w-1), w)
    overlap = np.outer(h-np.abs(yy), w-np.abs(xx))
    acov = acov / overlap
    acov = acov / acov[h-1, w-1]
    # Radial average around the zero-lag center; use pixel-radius bins.
    crop = min(128, h//2, w//2)
    ac_small = acov[h-1-crop:h+crop, w-1-crop:w+crop]
    ac_rad = radial_mean(ac_small)
    cross = next((i for i, v in enumerate(ac_rad) if i > 0 and v <= np.exp(-1)), None)
    corr_mm = cross / px_per_mm if cross is not None and px_per_mm else None

    # Hann-windowed 2D periodogram. With physical sampling, PSD integrates to variance.
    win = np.outer(np.hanning(h), np.hanning(w))
    norm = np.sum(win*win)
    spec = np.abs(np.fft.fftshift(np.fft.fft2(p*win)))**2 / norm
    dx_mm = 1.0 / px_per_mm if px_per_mm else 1.0
    if px_per_mm:
        dx_mm = 1.0 / px_per_mm
        spec = spec * dx_mm * dx_mm
        fy = np.fft.fftshift(np.fft.fftfreq(h, d=dx_mm))
        fx = np.fft.fftshift(np.fft.fftfreq(w, d=dx_mm))
        unit = "signal^2 * mm^2"
        df = min(1/(h*dx_mm), 1/(w*dx_mm))
    else:
        fy = np.fft.fftshift(np.fft.fftfreq(h))
        fx = np.fft.fftshift(np.fft.fftfreq(w))
        unit = "signal^2 * pixel^2"
        df = min(1/h, 1/w)
    FY, FX = np.meshgrid(fy, fx, indexing="ij")
    freq = np.sqrt(FX*FX + FY*FY)
    bins = np.floor(freq / df).astype(int)
    sums = np.bincount(bins.ravel(), weights=spec.ravel())
    counts = np.bincount(bins.ravel())
    psd_rad = sums / np.maximum(counts, 1)
    f_rad = (np.arange(len(psd_rad)) + 0.5) * df

    # Parseval check: integrating the 2-D periodogram over its frequency grid
    # should recover the Hann-window-weighted variance (up to floating error).
    psd_integral = float(np.sum(spec) / (h*w*dx_mm*dx_mm))
    windowed_variance = float(np.sum((p*win)**2) / norm)
    return {
        "mean_signal": mean_signal, "rms_signal": rms,
        "variance_signal": var, "windowed_variance": windowed_variance,
        "psd_integral": psd_integral,
        "psd_parseval_relative_error": float(abs(psd_integral-windowed_variance) / max(windowed_variance, 1e-30)),
        "detrend": detrend, "corr_length_px_1e": cross,
        "corr_length_mm_1e": corr_mm, "psd_units": unit,
        "autocorrelation_radial": ac_rad[:128].tolist(),
        "psd_radial": psd_rad[:256].tolist(),
        "frequency_cycles_per_mm": f_rad[:256].tolist() if px_per_mm else [],
        "autocorrelation_2d": acov, "psd_2d": spec,
        "frequency_x": fx, "frequency_y": fy,
    }


def analyze(path, outdir, roi=None, patch_width=256, px_per_mm=None, transfer="native", detrend="plane",
            density_calibration=None, aperture_um=None):
    img, source_meta = read_image_data(path, transfer)
    h, w = img.shape[:2]
    outdir = Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    regions = []
    if roi:
        x, y, rw, rh = roi
        if x < 0 or y < 0 or rw <= 0 or rh <= 0 or x+rw > w or y+rh > h:
            raise ValueError("ROI is outside image bounds.")
        regions = [("roi", img[y:y+rh, x:x+rw])]
    else:
        for i in range(5):
            x0, x1 = i*w//5, (i+1)*w//5
            side = min(patch_width, x1-x0, h-h//5)
            x = x0+(x1-x0-side)//2; y = (h-h//5-side)//2
            regions.append((f"patch_{i+1}", img[y:y+side, x:x+side]))
    results = []
    for name, patch in regions:
        if patch.ndim == 2:
            channel_arrays = {"gray": patch}
        else:
            channel_arrays = {c: patch[..., i] for i, c in enumerate(("red", "green", "blue"))}
        if density_calibration and patch.ndim != 2:
            raise ValueError("density calibration currently requires a grayscale scan; calibrate RGB channels separately")
        channel_results = {}
        residuals = {}
        spatial_arrays = {}
        for cname, cp in channel_arrays.items():
            m = metrics(cp, px_per_mm, detrend=detrend)
            residuals[cname] = detrend_patch(cp, detrend)
            spatial_arrays[f"{cname}_autocorrelation_2d"] = m.pop("autocorrelation_2d")
            spatial_arrays[f"{cname}_psd_2d"] = m.pop("psd_2d")
            spatial_arrays[f"{cname}_frequency_x"] = m.pop("frequency_x")
            spatial_arrays[f"{cname}_frequency_y"] = m.pop("frequency_y")
            channel_results[cname] = m
        names = list(residuals)
        if len(names) > 1:
            cov = np.cov(np.stack([residuals[k].ravel() for k in names]), bias=True)
            std = np.sqrt(np.maximum(np.diag(cov), 0))
            denom = np.outer(std, std)
            corr = np.divide(cov, denom, out=np.zeros_like(cov), where=denom > 1e-20)
            cross = {"channel_order": names, "residual_covariance": cov.tolist(),
                     "residual_correlation": corr.tolist()}
        else:
            cross = None
        np.savez_compressed(outdir/f"{name}_spatial.npz", **spatial_arrays)
        entry = {"name": name, "shape_px": list(patch.shape), "channels": channel_results,
                 "cross_channel": cross}
        if density_calibration:
            dark_signal, clear_signal, base_signal = density_calibration
            trans = transmittance_from_scan_signal(patch, dark_signal, clear_signal)
            base_t = float(transmittance_from_scan_signal(np.array([base_signal]), dark_signal, clear_signal)[0])
            density = transmittance_to_density(trans, base_t)
            dm = metrics(density, px_per_mm, detrend=detrend)
            dm.pop("autocorrelation_2d", None); dm.pop("psd_2d", None)
            dm.pop("frequency_x", None); dm.pop("frequency_y", None)
            entry["net_projection_density"] = dm
            entry["density_calibration"] = {
                "dark_signal": dark_signal, "clear_signal": clear_signal,
                "base_plus_fog_signal": base_signal, "base_plus_fog_transmittance": base_t,
                "assumption": "input scan values are linear with transmitted light; affine dark/clear calibration only"
            }
            if aperture_um is not None:
                if px_per_mm is None:
                    raise ValueError("--px-per-mm is required for aperture RMS")
                entry["aperture_rms"] = aperture_filtered_rms(density, px_per_mm, aperture_um, detrend)
        # Keep grayscale summary columns convenient for existing scripts.
        if "gray" in channel_results:
            entry.update({k: channel_results["gray"].get(k) for k in
                          ("mean_signal", "rms_signal", "variance_signal", "corr_length_px_1e", "corr_length_mm_1e")})
        results.append(entry)
    payload = {
        "schema_version": 3, "source": str(path), "image_size_px": [w, h],
        "source_metadata": source_meta, "source_integer_precision_preserved": True,
        "input_transfer": transfer, "px_per_mm": px_per_mm, "detrend": detrend,
        "density_calibration_enabled": density_calibration is not None,
        "aperture_um": aperture_um,
        "analysis_note": "Per-channel scan-domain statistics. They are not intrinsic ISO RMS granularity unless density calibration, aperture filtering, geometry, and instrument-noise correction are performed. Native transfer is the safe default for unknown scanner encodings.",
        "patches": results
    }
    (outdir/"metrics.json").write_text(json.dumps(payload, indent=2))
    fields = ["name", "channel", "mean_signal", "rms_signal", "variance_signal", "corr_length_px_1e", "corr_length_mm_1e"]
    with (outdir/"summary.csv").open("w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=fields); wr.writeheader()
        for r in results:
            for cname, cm in r["channels"].items():
                wr.writerow({"name": r["name"], "channel": cname,
                             **{k:cm.get(k) for k in fields[2:]}})
    fig, axs = plt.subplots(1,2, figsize=(12,4))
    for r in results:
        for cname, cm in r["channels"].items():
            label = f"{r['name']}:{cname}"
            if cm["autocorrelation_radial"]:
                axs[0].plot(cm["autocorrelation_radial"], label=label)
                axs[1].loglog(np.maximum(cm["psd_radial"][1:], 1e-18), label=label)
    axs[0].set(title="Radial autocorrelation", xlabel="Lag (pixels)", ylabel="Normalized correlation"); axs[0].grid(True)
    axs[1].set(title="Radially averaged periodogram", xlabel="Radial frequency bin", ylabel="Power"); axs[1].grid(True)
    if axs[0].lines:
        axs[0].legend()
    if axs[1].lines:
        axs[1].legend()
    fig.tight_layout(); fig.savefig(outdir/"spectral_diagnostics.png", dpi=150); plt.close(fig)
    return payload

def selftest(outdir):
    outdir = Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(20261108)
    n = 512
    white = rng.normal(size=(n,n))
    kernel = np.zeros((15,15)); yy,xx = np.mgrid[-7:8,-7:8]
    kernel = np.exp(-(xx*xx+yy*yy)/(2*2.0**2)); kernel /= kernel.sum()
    correlated = signal.fftconvolve(rng.normal(size=(n,n)), kernel, mode="same")
    constant = np.full((n,n), 0.42)
    m_white = metrics(white)
    m_corr = metrics(correlated)
    m_const = metrics(constant)
    assert abs(m_white["rms_signal"]-1) < 0.04, m_white["rms_signal"]
    assert m_corr["corr_length_px_1e"] is not None and m_corr["corr_length_px_1e"] > 1
    assert m_white["corr_length_px_1e"] in (1,2,3)
    assert m_const["corr_length_px_1e"] is None
    report = {
        "seed": 20261108,
        "white_noise": {k:m_white[k] for k in ["rms_signal","corr_length_px_1e"]},
        "correlated_noise": {k:m_corr[k] for k in ["rms_signal","corr_length_px_1e"]},
        "constant_field": {k:m_const[k] for k in ["rms_signal","corr_length_px_1e"]},
        "assertions": "PASS"
    }
    (outdir/"selftest.json").write_text(json.dumps(report, indent=2))
    return report


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("target"); g.add_argument("--out", default="research/data/emulsion_test_target.tif")
    g.add_argument("--size", type=int, default=2048); g.add_argument("--bit-depth", type=int, choices=[8,16], default=16)
    a = sub.add_parser("analyze"); a.add_argument("image"); a.add_argument("--out", default="research/results")
    a.add_argument("--roi", nargs=4, type=int, metavar=("X","Y","W","H")); a.add_argument("--patch-width", type=int, default=256)
    a.add_argument("--px-per-mm", type=float); a.add_argument("--transfer", choices=["native","srgb","linear"], default="native")
    a.add_argument("--detrend", choices=["none","constant","plane"], default="plane")
    a.add_argument("--density-calibration", nargs=3, type=float, metavar=("DARK", "CLEAR", "BASE"),
                   help="Use only for a known linear-transmittance scan; normalized signal values for dark, clear-film, and base+fog references.")
    a.add_argument("--aperture-um", type=float, help="Optional digital circular-aperture RMS diagnostic (requires density calibration and --px-per-mm).")
    t = sub.add_parser("selftest"); t.add_argument("--out", default="research/results/selftest_v2")
    args = ap.parse_args()
    if args.cmd == "target":
        levels = make_target(args.out,args.size,args.bit_depth); print(json.dumps({"created":args.out, "image_size_px":[args.size,args.size], "gray_levels_8bit":levels, "bit_depth":args.bit_depth}))
    elif args.cmd == "analyze":
        if args.aperture_um is not None and args.density_calibration is None:
            ap.error("--aperture-um requires --density-calibration")
        res = analyze(args.image,args.out,args.roi,args.patch_width,args.px_per_mm,args.transfer,args.detrend,
                      args.density_calibration,args.aperture_um)
        print(json.dumps({"output":args.out,"patches":[{k:r.get(k) for k in ["name","shape_px","channels","cross_channel"]} for r in res["patches"]]},indent=2))
    else:
        print(json.dumps(selftest(args.out),indent=2))

if __name__ == "__main__":
    main()
