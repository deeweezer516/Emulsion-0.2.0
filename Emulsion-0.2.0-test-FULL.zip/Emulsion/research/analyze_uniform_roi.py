#!/usr/bin/env python3
"""Analyze a uniformly exposed film ROI as a collection of independent tiles.

This is a scan-domain research tool. It requires explicit affine scanner
calibration and base+fog reference. Its aperture RMS is a digital projection-
density diagnostic, NOT an ISO 10505 intrinsic diffuse-density measurement.
"""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
import numpy as np
from bench import read_image_data, transmittance_from_scan_signal, transmittance_to_density, metrics, aperture_filtered_rms


def _moving_block_bootstrap(values, grid_shape, block_tiles, bootstrap, rng):
    """Spatial moving-block bootstrap over the tile grid.

    Samples contiguous b x b tile blocks with replacement until the original
    number of tiles is reached. This preserves short-range dependence within
    each sampled block better than IID tile resampling. It does NOT account
    for between-frame, scanner-calibration, or film-batch uncertainty.
    """
    values = np.asarray(values, dtype=float).reshape(grid_shape)
    ny, nx = grid_shape
    b = int(block_tiles)
    if b < 1 or b > min(nx, ny):
        raise ValueError('block_tiles must be between 1 and the smaller tile-grid dimension')
    n = values.size
    estimates = np.empty(int(bootstrap), dtype=float)
    for k in range(int(bootstrap)):
        sample = []
        while len(sample) < n:
            y0 = int(rng.integers(0, ny-b+1))
            x0 = int(rng.integers(0, nx-b+1))
            sample.extend(values[y0:y0+b, x0:x0+b].ravel().tolist())
        a = np.asarray(sample[:n], dtype=float)
        estimates[k] = np.sqrt(np.mean(a*a))
    return np.quantile(estimates, [0.025, 0.5, 0.975]).tolist()


def _neighbor_tile_correlation(values, grid_shape):
    """Descriptive lag-one correlation of tile RMS; None if undefined."""
    a = np.asarray(values, dtype=float).reshape(grid_shape)
    pairs = []
    if a.shape[1] > 1:
        pairs.append((a[:, :-1].ravel(), a[:, 1:].ravel()))
    if a.shape[0] > 1:
        pairs.append((a[:-1, :].ravel(), a[1:, :].ravel()))
    xx = np.concatenate([q[0] for q in pairs]) if pairs else np.array([])
    yy = np.concatenate([q[1] for q in pairs]) if pairs else np.array([])
    if len(xx) < 3 or np.std(xx) == 0 or np.std(yy) == 0:
        return None
    return float(np.corrcoef(xx, yy)[0, 1])


def analyze_uniform_roi(image_path, roi, dark, clear, base, px_per_mm,
                        tile_px=256, aperture_um=48.0, bootstrap=2000, seed=20261108,
                        transfer='native', block_tiles=2):
    img, meta = read_image_data(image_path, transfer)
    if img.ndim != 2:
        raise ValueError('Use a grayscale master scan. Analyze RGB channels separately; do not silently combine them.')
    x, y, w, h = map(int, roi)
    if x < 0 or y < 0 or w <= 0 or h <= 0 or x+w > img.shape[1] or y+h > img.shape[0]:
        raise ValueError('ROI is outside image bounds')
    if tile_px < 64:
        raise ValueError('tile_px must be >=64')
    if bootstrap < 100:
        raise ValueError('bootstrap must be >=100')
    raw = img[y:y+h, x:x+w]
    trans = transmittance_from_scan_signal(raw, dark, clear)
    base_t = float(transmittance_from_scan_signal(np.array([base]), dark, clear)[0])
    density = transmittance_to_density(trans, base_t)
    if not np.all(np.isfinite(density)):
        raise ValueError('Non-finite density after calibration')

    tiles = []
    for yy in range(0, h-tile_px+1, tile_px):
        for xx in range(0, w-tile_px+1, tile_px):
            p = density[yy:yy+tile_px, xx:xx+tile_px]
            m = metrics(p, px_per_mm=px_per_mm, detrend='plane')
            ap = aperture_filtered_rms(p, px_per_mm, diameter_um=aperture_um, detrend='plane')
            tiles.append({
                'tile_x_px': xx, 'tile_y_px': yy,
                'mean_net_projection_density': float(np.mean(p)),
                'rms_net_projection_density_scan_domain': m['rms_signal'],
                'aperture_equivalent_projection_density_rms': ap['rms_projection_density'],
                'aperture_equivalent_x1000': ap['aperture_rms_x1000'],
                'corr_length_px_1e': m['corr_length_px_1e'],
                'corr_length_mm_1e': m['corr_length_mm_1e'],
                'psd_parseval_relative_error': m['psd_parseval_relative_error'],
            })
    grid_ny = len(range(0, h-tile_px+1, tile_px))
    grid_nx = len(range(0, w-tile_px+1, tile_px))
    if len(tiles) < 4:
        raise ValueError(f'Only {len(tiles)} complete tiles. Need >=4; enlarge ROI or reduce tile_px.')
    if block_tiles < 1 or block_tiles > min(grid_nx, grid_ny):
        raise ValueError(f'block_tiles={block_tiles} is invalid for tile grid {grid_nx}x{grid_ny}')

    rms = np.array([t['rms_net_projection_density_scan_domain'] for t in tiles])
    ap_rms = np.array([t['aperture_equivalent_projection_density_rms'] for t in tiles])
    rng = np.random.default_rng(seed)
    # Bootstrap tiles as sampling units. This CI captures between-tile variation,
    # not all sources of uncertainty (scanner calibration, MTF, film batch, etc.).
    idx = rng.integers(0, len(tiles), size=(bootstrap, len(tiles)))
    boot_rms = np.sqrt(np.mean(rms[idx]**2, axis=1))
    boot_ap = np.sqrt(np.mean(ap_rms[idx]**2, axis=1))
    ci_rms_iid = np.quantile(boot_rms, [0.025, 0.5, 0.975])
    ci_ap_iid = np.quantile(boot_ap, [0.025, 0.5, 0.975])
    # Resample contiguous spatial blocks of tiles to reduce the optimistic
    # uncertainty that IID tile bootstrap can produce for correlated fields.
    ci_rms_block = _moving_block_bootstrap(rms, (grid_ny, grid_nx), block_tiles, bootstrap, rng)
    ci_ap_block = _moving_block_bootstrap(ap_rms, (grid_ny, grid_nx), block_tiles, bootstrap, rng)
    summary = {
        'schema_version': 1,
        'status': 'scan-domain exploratory estimate; NOT intrinsic ISO 10505 RMS granularity',
        'source': str(image_path), 'source_metadata': meta,
        'roi_xywh_px': [x, y, w, h], 'tile_px': tile_px, 'tile_count': len(tiles),
        'calibration': {
            'method': 'affine dark/clear scanner calibration followed by base+fog normalization',
            'dark_signal_normalized': float(dark), 'clear_signal_normalized': float(clear),
            'base_plus_fog_signal_normalized': float(base),
            'base_plus_fog_transmittance': base_t,
            'assumptions': [
                'scan code values are proportional to transmitted light after the selected transfer function',
                'scanner response is affine between dark and clear references',
                'no automatic exposure, gamma, sharpening, denoising, dust removal or nonlinear tone curve',
                'the base+fog reference corresponds to the same film support and scan setup'
            ]
        },
        'sampling': {'px_per_mm': float(px_per_mm), 'aperture_diameter_um': float(aperture_um),
                     'tile_grid_xy': [grid_nx, grid_ny], 'spatial_block_tiles': int(block_tiles),
                     'bootstrap_replicates': int(bootstrap), 'bootstrap_seed': int(seed)},
        'results': {
            'mean_net_projection_density': float(np.mean(density)),
            'scan_domain_tile_rms_mean': float(np.mean(rms)),
            'scan_domain_tile_rms_ci95_iid_diagnostic': ci_rms_iid.tolist(),
            'scan_domain_tile_rms_ci95_spatial_block': ci_rms_block,
            'scan_domain_tile_rms_ci95_percentile': ci_rms_block,  # compatibility alias; spatial-block CI
            'aperture_equivalent_rms_ci95_iid_diagnostic': ci_ap_iid.tolist(),
            'aperture_equivalent_rms_ci95_spatial_block': ci_ap_block,
            'neighbor_tile_rms_lag1_correlation': _neighbor_tile_correlation(rms, (grid_ny, grid_nx)),
            'digital_aperture_equivalent_projection_density_rms_mean': float(np.mean(ap_rms)),
            'digital_aperture_equivalent_projection_density_rms_ci95_percentile': ci_ap.tolist(),
            'tile_rms_cv': float(np.std(rms, ddof=1)/np.mean(rms)) if np.mean(rms)>0 else None,
            'mean_corr_length_mm_1e': float(np.nanmean([t['corr_length_mm_1e'] for t in tiles])) if any(t['corr_length_mm_1e'] is not None for t in tiles) else None,
            'mean_parseval_relative_error': float(np.mean([t['psd_parseval_relative_error'] for t in tiles]))
        },
        'limitations': [
            'spatial block bootstrap preserves dependence only within the chosen tile block; block size is a sensitivity parameter',
            'IID tile bootstrap is retained only as a diagnostic and can understate uncertainty when neighboring tiles are correlated',
            'bootstrap intervals reflect within-ROI spatial sampling only',
            'scanner noise and scanner MTF have not been independently removed',
            'digital aperture kernel is a geometric approximation, not a complete microdensitometer transfer function',
            'projection-density estimate is not directly interchangeable with diffuse-density ISO granularity',
            'a single uniform patch cannot establish density dependence or stock-wide profile'
        ],
        'tiles': tiles
    }
    return summary


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('image')
    ap.add_argument('--roi', nargs=4, type=int, required=True, metavar=('X','Y','W','H'))
    ap.add_argument('--dark', type=float, required=True, help='normalized scanner dark reference')
    ap.add_argument('--clear', type=float, required=True, help='normalized clear reference')
    ap.add_argument('--base', type=float, required=True, help='normalized base+fog reference')
    ap.add_argument('--px-per-mm', type=float, required=True)
    ap.add_argument('--tile-px', type=int, default=256)
    ap.add_argument('--aperture-um', type=float, default=48.0)
    ap.add_argument('--bootstrap', type=int, default=2000)
    ap.add_argument('--seed', type=int, default=20261108)
    ap.add_argument('--block-tiles', type=int, default=2, help='moving spatial bootstrap block width/height in tiles (default 2)')
    ap.add_argument('--transfer', choices=['native','linear','srgb'], default='native')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    result = analyze_uniform_roi(a.image, a.roi, a.dark, a.clear, a.base,
                                 a.px_per_mm, a.tile_px, a.aperture_um,
                                 a.bootstrap, a.seed, a.transfer, a.block_tiles)
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    (out.with_suffix('.json')).write_text(json.dumps(result, indent=2))
    with out.with_suffix('.csv').open('w', newline='') as f:
        fields = list(result['tiles'][0].keys())
        wr = csv.DictWriter(f, fieldnames=fields); wr.writeheader(); wr.writerows(result['tiles'])
    print(json.dumps({'out': str(out), 'tile_count': result['tile_count'], 'results': result['results'], 'status': result['status']}, indent=2))

if __name__ == '__main__':
    main()
