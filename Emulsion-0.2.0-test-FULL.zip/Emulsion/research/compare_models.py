#!/usr/bin/env python3
"""Generate a synthetic-only side-by-side model diagnostics figure.

The values are deliberately arbitrary and must never be labelled as a film stock.
"""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from boolean_grain_model import render_boolean_grain
from spectral_grain_model import render_spectral_density
from bench import metrics

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results'/'model_comparison_synthetic'
OUT.mkdir(parents=True,exist_ok=True)
N=256
D=np.ones((N,N),dtype=np.float64)*0.85
pxmm=2000.0
# Boolean model: arbitrary geometric parameters, not a Tri-X/HP5 profile.
b=render_boolean_grain(D,pxmm,mean_radius_um=1.4,radius_cv=0.25,blur_sigma_um=0.25,supersample=4,seed=17,max_grains=200000)
# Empirical PSD model: arbitrary density-noise curve and scales.
s=render_spectral_density(D,pxmm,[0.0,0.85,1.7],[0.0,0.018,0.014],scales_um=(1.5,5.0),weights=(0.65,0.35),white_floor=0.015,seed=17)
# Keep model domains separate: Boolean output is transmittance; spectral output is
# a density residual. A direct conversion is invalid where binary coverage reaches 1.
Tb=b['transmittance']
Cb=b['coverage']
Rs=s['residual']
# Simple radial PSDs of detrended fields for display only.
def radial_psd(x):
    x=x-x.mean(); w=np.outer(np.hanning(x.shape[0]),np.hanning(x.shape[1]))
    F=np.fft.fftshift(np.fft.fft2(x*w))
    P=(np.abs(F)**2)/(np.sum(w*w))
    fy=np.fft.fftshift(np.fft.fftfreq(x.shape[0],d=1/pxmm))
    fx=np.fft.fftshift(np.fft.fftfreq(x.shape[1],d=1/pxmm))
    yy,xx=np.meshgrid(fy,fx,indexing='ij'); rr=np.sqrt(xx*xx+yy*yy)
    bins=np.linspace(0,pxmm/2,90)
    ids=np.digitize(rr.ravel(),bins)
    val=np.array([P.ravel()[ids==i].mean() if np.any(ids==i) else np.nan for i in range(1,len(bins))])
    return (bins[:-1]+bins[1:])/2,val
f1,p1=radial_psd(Cb); f2,p2=radial_psd(Rs)
fig,axs=plt.subplots(2,2,figsize=(11,8),constrained_layout=True)
axs[0,0].imshow(Tb,cmap='gray',vmin=0,vmax=1); axs[0,0].set_title('Boolean model: transmittance (synthetic)'); axs[0,0].axis('off')
axs[0,1].imshow(Rs,cmap='gray'); axs[0,1].set_title('Spectral Gaussian residual (synthetic)'); axs[0,1].axis('off')
axs[1,0].plot(f1,p1,label='Boolean coverage'); axs[1,0].plot(f2,p2,label='Spectral density residual'); axs[1,0].set_yscale('log'); axs[1,0].set_xlabel('Spatial frequency (cycles/mm)'); axs[1,0].set_ylabel('Relative periodogram'); axs[1,0].set_title('Radially averaged PSD shapes (different domains)'); axs[1,0].legend()
axs[1,1].hist(Tb.ravel(),bins=32,alpha=0.65,label='Boolean transmittance'); axs[1,1].hist(Rs.ravel(),bins=32,alpha=0.65,label='Spectral density residual'); axs[1,1].set_ylabel('Pixel count'); axs[1,1].set_title('Value distributions (different domains)'); axs[1,1].legend()
fig.suptitle('SYNTHETIC MODEL DIAGNOSTICS — arbitrary parameters, NOT film measurements',fontsize=13,fontweight='bold')
fig.savefig(OUT/'comparison.png',dpi=160)
summary={
 'status':'synthetic software experiment only; no real film samples used',
 'image_shape':[N,N], 'px_per_mm':pxmm, 'input_net_density':0.85,
 'boolean':b['diagnostics'],
 'spectral':s['diagnostics'],
 'boolean_transmittance_mean':float(Tb.mean()),
 'boolean_transmittance_zero_fraction':float(np.mean(Tb <= 1e-8)),
 'boolean_coverage_std':float(Cb.std()),
 'spectral_residual_std':float(Rs.std()),
 'interpretation':'The outputs are intentionally not converted to a common domain. Boolean binary coverage can produce exactly opaque pixels; converting those to optical density yields infinities and arbitrary clipping. A calibrated grain-opacity/optical-density mapping is required before direct density-domain comparison.'
}
import json
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
