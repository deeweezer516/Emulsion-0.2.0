#!/usr/bin/env python3
import numpy as np
from rgb_common_mode import estimate_common_mode


def test_recovers_common_and_independent_noise():
    rng = np.random.default_rng(812)
    h = w = 256
    common = rng.normal(0, 0.02, (h, w))
    noise = rng.normal(0, 0.005, (h, w, 3))
    rgb = common[..., None] + noise
    got = estimate_common_mode(rgb)
    assert abs(got['estimated_common_variance_density2'] - 0.02**2) < 2.0e-5
    for ch in 'RGB':
        assert abs(got['estimated_channel_specific_variance_density2'][ch] - 0.005**2) < 2.0e-5
    assert got['negative_residual_channel_count'] == 0


def test_rejects_non_rgb_and_nonfinite():
    try:
        estimate_common_mode(np.zeros((32,32)))
        raise AssertionError('expected ValueError')
    except ValueError:
        pass
    x = np.zeros((32,32,3)); x[0,0,0] = np.nan
    try:
        estimate_common_mode(x)
        raise AssertionError('expected ValueError')
    except ValueError:
        pass


def test_reports_inconsistent_correlated_channel_noise():
    rng = np.random.default_rng(813)
    h = w = 128
    common = rng.normal(0, 0.005, (h,w))
    shared_scanner = rng.normal(0, 0.03, (h,w))
    # Channel-specific processing causes negative estimated residual variance
    # in at least one channel under the equal-gain model.
    rgb = np.stack([common + shared_scanner,
                    common - shared_scanner,
                    common + rng.normal(0, 0.001, (h,w))], axis=-1)
    got = estimate_common_mode(rgb)
    assert not got['common_variance_nonnegative']
    assert 'inconsistent' in got['diagnostic_warning']
    assert len(got['pairwise_common_covariance_density2']) == 3
