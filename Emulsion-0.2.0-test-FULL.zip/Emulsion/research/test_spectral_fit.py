#!/usr/bin/env python3
"""Recover known two-scale PSD parameters from a synthetic spectrum."""
import numpy as np
from spectral_grain_model import gaussian_mixture_psd, fit_gaussian_mixture_psd


def main():
    n, px = 1024, 4000.0
    scales, weights, floor = (1.5, 6.0), (0.65, 0.35), 0.02
    psd = gaussian_mixture_psd((n,n), px, scales, weights, floor)
    fy = np.fft.fftfreq(n, d=1/px); fx = np.fft.rfftfreq(n, d=1/px)
    yy, xx = np.meshgrid(fy, fx, indexing='ij'); rr = np.sqrt(xx*xx+yy*yy)
    df = px/n; bins = np.arange(0, px/2+df, df); ids = np.digitize(rr.ravel(), bins)
    radial = np.array([psd.ravel()[ids==i].mean() if np.any(ids==i) else np.nan for i in range(1,len(bins))])
    f = (bins[:-1]+bins[1:])/2; ok = np.isfinite(radial)
    fit = fit_gaussian_mixture_psd(f[ok], radial[ok])
    assert fit['success']
    assert abs(fit['scales_um'][0]-1.5) < 0.08, fit
    assert abs(fit['scales_um'][1]-6.0) < 0.3, fit
    assert abs(fit['white_floor']-0.02) < 0.005, fit
    print('PASS: two-scale PSD fit recovers known synthetic parameters')
    print(fit)

if __name__ == '__main__': main()
