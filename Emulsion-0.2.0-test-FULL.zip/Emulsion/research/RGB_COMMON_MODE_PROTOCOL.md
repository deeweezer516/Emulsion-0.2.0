# RGB common-mode diagnostic (v0.8)

## Purpose

For a uniformly imaged black-and-white negative, the same silver-density
fluctuation is observed by all scanner colour channels. Some detector/electronic
noise may be channel-specific. Cross-channel covariance can therefore help
separate a shared component from channel-specific residuals. Grainifier's
public README describes a related three-cornered-hat analysis.

## Current implementation

`rgb_common_mode.py` accepts an `H x W x 3` array of calibrated density values.
It independently removes a fitted plane from each channel, computes the 3x3
sample covariance matrix, estimates the shared variance as the mean of the
three off-diagonal covariances, and estimates each channel-specific variance
as its diagonal covariance minus the shared estimate.

The function returns pairwise covariances, correlations, common-mode RMS,
channel residual RMS, and warnings when the implied covariance decomposition
is not physically feasible.

## Assumptions and limitations

This is an intentionally conservative diagnostic, not a validated scanner-noise
subtraction. It assumes:

1. R/G/B have been mapped into comparable density units using a documented,
   channel-specific calibration.
2. The common silver-grain signal has approximately equal gain in all three
   calibrated channels.
3. Channel-specific noise terms are mutually uncorrelated.
4. The patch is uniform and contains no image texture, dust, scratches,
   sharpening halos, demosaicing artefacts, or channel-dependent local tone
   processing.

Real scanners may violate all four assumptions. In particular, scanner
channels may have correlated electronics/processing noise and different
spectral responses to silver. A non-negative covariance decomposition does
not prove the assumptions. A negative estimated common covariance or negative
residual variance is evidence that the simple model is inconsistent with the
data; do not clip and silently continue.

## Required validation before use on real scans

- Calibrate each channel independently using stable clear, dark and base+fog
  references; retain calibration coefficients.
- Measure scanner-only repeatability using repeated scans of a stable target.
- Compare single-pass and multi-pass scans; do not pool them without modelling
  their different noise/MTF behaviour.
- Test the model on a uniform target with no film, then on a uniform developed
  negative.
- Inspect covariance and coherence as a function of spatial frequency, not
  only scalar variance. The current v0.8 function is a spatial-domain first
  diagnostic; it does not yet estimate cross-spectral matrices.
- Validate on independent frames/rolls before attributing the common component
  to emulsion grain.

## Synthetic tests

The tests create a known common random field plus independent channel noise and
check recovery of the variance components. A separate deliberately
inconsistent example checks that negative common covariance is flagged. These
are implementation tests, not evidence that a particular scanner obeys the
model.
