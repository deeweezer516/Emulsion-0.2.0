# 0.2.0-test

- Bumped Android app version to 0.2.0-test.
- Added selectable correlated-field and experimental thresholded particle-field render modes.
- Added monochrome shared-noise mode.
- Added shadow/highlight response controls.
- Added deterministic seed variation action.
- Preserved the full Research Bench 0.9 source, test data, diagnostics and documentation.
- Added explicit Android/research integration status and calibration caveats.

Not included: a calibrated Tri-X/HP5 profile, a full Boolean particle renderer in Android, RAW/TIFF/16-bit processing, metadata/ICC preservation or a verified physical-film accuracy claim.
